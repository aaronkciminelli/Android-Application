package com.example.aaronciminellifp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class ShareEventActivity extends AppCompatActivity {

    private Button shareEventButton;
    private EventPlannerDatabase eventPlannerDatabase;
    private List<Event> eventList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_event);

        shareEventButton = findViewById(R.id.shareEventButton);
        eventPlannerDatabase = EventPlannerDatabase.getInstance(this);
        eventList = eventPlannerDatabase.eventList();

        shareEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show a dialog to confirm sharing the events
                new AlertDialog.Builder(ShareEventActivity.this)
                        .setTitle("Share events")
                        .setMessage("Are you sure you want to share all events?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Create an intent to share the events
                                Intent intent = new Intent(Intent.ACTION_SEND);
                                intent.setType("text/plain");

                                StringBuilder stringBuilder = new StringBuilder();

                                // Add each event to the string builder
                                for (Event event : eventList) {
                                    stringBuilder.append(event.getDetails());
                                    stringBuilder.append(", ");
                                    stringBuilder.append(event.getDate());
                                    stringBuilder.append(", ");
                                    stringBuilder.append(event.getTime());
                                    stringBuilder.append(", ");
                                    stringBuilder.append(event.getLocation());
                                    stringBuilder.append("\n");
                                }

                                // Set the text to be shared and start the activity
                                intent.putExtra(Intent.EXTRA_TEXT, stringBuilder.toString());
                                startActivity(Intent.createChooser(intent, "Share events"));
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });
    }
}
