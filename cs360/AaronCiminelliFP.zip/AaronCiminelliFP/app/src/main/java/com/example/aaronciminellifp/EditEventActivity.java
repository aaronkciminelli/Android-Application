package com.example.aaronciminellifp;

import static com.example.aaronciminellifp.R.id.eventDetailsEditText;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditEventActivity extends AppCompatActivity {

    private EditText eventDetailsEditText, eventDateEditText, eventTimeEditText, eventLocationEditText;
    private Button saveChangesButton;
    private EventPlannerDatabase eventPlannerDatabase;
    private int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        eventDetailsEditText = findViewById(R.id.eventDetailsEditText);
        eventDateEditText = findViewById(R.id.eventDateEditText);
        eventTimeEditText = findViewById(R.id.eventTimeEditText);
        eventLocationEditText = findViewById(R.id.eventLocationEditText);
        saveChangesButton = findViewById(R.id.saveEventButton);

        eventPlannerDatabase = EventPlannerDatabase.getInstance(this);
        eventId = getIntent().getIntExtra("eventId", -1);

        Event event = eventPlannerDatabase.getEventById(eventId);
        if (event != null) {
            eventDetailsEditText.setText(event.getDetails());
            eventDateEditText.setText(event.getDate());
            eventTimeEditText.setText(event.getTime());
            eventLocationEditText.setText(event.getLocation());
        }

        saveChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String eventDetails = eventDetailsEditText.getText().toString().trim();
                String eventDate = eventDateEditText.getText().toString().trim();
                String eventTime = eventTimeEditText.getText().toString().trim();
                String eventLocation = eventLocationEditText.getText().toString().trim();

                if (eventDetails.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty() || eventLocation.isEmpty()) {
                    Toast.makeText(EditEventActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                Event updatedEvent = new Event(eventId, eventDetails, eventDate, eventTime, eventLocation, event.getUserId());
                eventPlannerDatabase.updateEvent(updatedEvent);
                Toast.makeText(EditEventActivity.this, "Event updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}