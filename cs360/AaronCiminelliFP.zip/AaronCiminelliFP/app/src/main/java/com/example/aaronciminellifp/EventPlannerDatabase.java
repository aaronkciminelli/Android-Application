package com.example.aaronciminellifp;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;

public class EventPlannerDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "eventplannerdb.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_NAME = "users";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_IS_ADMIN = "is_admin";
    private static final String COLUMN_FIRST_NAME = "first_name";
    private static final String COLUMN_LAST_NAME = "last_name";
    private static final String COLUMN_EMAIL = "email";
    private static final String TABLE_USERS = "users";
    private static final String TABLE_EVENTS = "events";
    private static final String COLUMN_EVENT_ID = "_id";
    private static final String COLUMN_EVENT_DETAILS = "event_details";
    private static final String COLUMN_EVENT_DATE = "event_date";
    private static final String COLUMN_EVENT_TIME = "event_time";
    private static final String COLUMN_EVENT_LOCATION = "event_location";
    private static final String COLUMN_USER_ID = "user_id";

    private static EventPlannerDatabase instance;

    public ArrayList<Event> eventList() {
        String query = "SELECT * FROM " + TABLE_EVENTS;
        return retrieveEvents(query, null);
    }

    public ArrayList<Event> getEventsByUserId(int userId) {
        String query = "SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_USER_ID + "=?";
        return retrieveEvents(query, new String[]{String.valueOf(userId)});
    }

    private ArrayList<Event> retrieveEvents(String query, String[] selectionArgs) {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Event> events = new ArrayList<>();
        Cursor cursor = db.rawQuery(query, selectionArgs);

        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(COLUMN_EVENT_ID);
                int detailsIndex = cursor.getColumnIndex(COLUMN_EVENT_DETAILS);
                int dateIndex = cursor.getColumnIndex(COLUMN_EVENT_DATE);
                int timeIndex = cursor.getColumnIndex(COLUMN_EVENT_TIME);
                int locationIndex = cursor.getColumnIndex(COLUMN_EVENT_LOCATION);
                int userIdIndex = cursor.getColumnIndex(COLUMN_USER_ID);

                if (idIndex != -1 && detailsIndex != -1 && dateIndex != -1 && timeIndex != -1 && locationIndex != -1 && userIdIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String details = cursor.getString(detailsIndex);
                    String date = cursor.getString(dateIndex);
                    String time = cursor.getString(timeIndex);
                    String location = cursor.getString(locationIndex);
                    int userId = cursor.getInt(userIdIndex);

                    events.add(new Event(id, details, date, time, location, userId));
                }
            } while (cursor.moveToNext());
        }

        cursor.close();
        return events;
    }
    public Event getEventById(int eventId) {
        SQLiteDatabase db = getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_EVENT_ID + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(eventId)});

        Event event = null;
        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(COLUMN_EVENT_ID);
            int detailsIndex = cursor.getColumnIndex(COLUMN_EVENT_DETAILS);
            int dateIndex = cursor.getColumnIndex(COLUMN_EVENT_DATE);
            int timeIndex = cursor.getColumnIndex(COLUMN_EVENT_TIME);
            int locationIndex = cursor.getColumnIndex(COLUMN_EVENT_LOCATION);
            int userIdIndex = cursor.getColumnIndex(COLUMN_USER_ID);

            if (idIndex != -1 && detailsIndex != -1 && dateIndex != -1 && timeIndex != -1 && locationIndex != -1 && userIdIndex != -1) {
                int id = cursor.getInt(idIndex);
                String details = cursor.getString(detailsIndex);
                String date = cursor.getString(dateIndex);
                String time = cursor.getString(timeIndex);
                String location = cursor.getString(locationIndex);
                int userId = cursor.getInt(userIdIndex);

                event = new Event(id, details, date, time, location, userId);
            }
        }

        cursor.close();
        return event;
    }



    public static synchronized EventPlannerDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new EventPlannerDatabase(context.getApplicationContext());
            // create the admin user
            instance.createAdminUser();
        }
        return instance;
    }
    private boolean isAdminUserExists() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME +
                " WHERE " + COLUMN_USERNAME + "=?", new String[]{"admin"});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    private EventPlannerDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        String dbPath = getReadableDatabase().getPath();
        Log.d("DATABASE", "Database path: " + dbPath);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create the users table
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_FIRST_NAME + " TEXT, " +
                COLUMN_LAST_NAME + " TEXT, " +
                COLUMN_EMAIL + " TEXT, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_IS_ADMIN + " INTEGER DEFAULT 0)"); // set the default value of isAdmin to 0

    // create the events table
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + "(" +
                COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_DETAILS + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT, " +
                COLUMN_EVENT_TIME + " TEXT, " +
                COLUMN_EVENT_LOCATION + " TEXT, " +
                COLUMN_USER_ID + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + "))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop the users table and create a new one
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

        // drop the events table and create a new one
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        // query the users table for the username and password
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME +
                " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?", new String[]{username, password});

        boolean loginSuccessful = false;
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int isAdminIndex = cursor.getColumnIndex(COLUMN_IS_ADMIN);
            int idIndex = cursor.getColumnIndex(COLUMN_ID);

            // Check if the column indices are non-negative
            if (isAdminIndex != -1 && idIndex != -1) {
                loginSuccessful = true;
                int userId = cursor.getInt(idIndex); // Get the user ID
            }
        }
        cursor.close();
        return loginSuccessful;
    }


    public boolean createUser(String firstName, String lastName, String email, String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String dbPath = db.getPath();
        Log.d("DATABASE", "Database path: " + dbPath);

        // check if the user already exists
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME +
                " WHERE " + COLUMN_USERNAME + "=? OR " + COLUMN_EMAIL + "=?", new String[]{username, email});

        if (cursor.getCount() > 0) {
            // Delete the first user with the same username or email
            cursor.moveToFirst();
            int usernameColumnIndex = cursor.getColumnIndex(COLUMN_USERNAME);
            if (usernameColumnIndex != -1) {
                String existingUsername = cursor.getString(usernameColumnIndex);
                deleteUser(existingUsername);
            }

            cursor.close();

            // Prompt the user to enter new details
            return false;
        }

        // create a new user
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRST_NAME, firstName);
        values.put(COLUMN_LAST_NAME, lastName);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long rowId = db.insert(TABLE_NAME, null, values);
        cursor.close();
        return rowId != -1; // return true if the user was created successfully

    }
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_DETAILS, event.getDetails());
        values.put(COLUMN_EVENT_DATE, event.getDate());
        values.put(COLUMN_EVENT_TIME, event.getTime());
        values.put(COLUMN_EVENT_LOCATION, event.getLocation());

        int rowsUpdated = db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(event.getId())});

        return rowsUpdated > 0;
    }


    public boolean createAdminUser() {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // Check if admin user already exists
        if (isAdminUserExists()) {
            return true;
        }

        // set the username and password for the admin user
        values.put(COLUMN_USERNAME, "admin");
        values.put(COLUMN_PASSWORD, "password");
        values.put(COLUMN_IS_ADMIN, 1); // set the isAdmin flag to 1

        // insert the values into the users table
        long result = db.insert(TABLE_USERS, null, values);

        // return true if the insert was successful, false otherwise
        return result != -1;
    }

    public boolean deleteUser(String username) {
        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(TABLE_NAME, COLUMN_USERNAME + "=?", new String[]{username});

        return rowsDeleted > 0;
    }

    //add event
    public boolean addEvent(int userId, String details, String date, String time, String location) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_DETAILS, details);
        values.put(COLUMN_EVENT_DATE, date);
        values.put(COLUMN_EVENT_TIME, time);
        values.put(COLUMN_EVENT_LOCATION, location);
        values.put(COLUMN_USER_ID, userId);

        long rowId = db.insert(TABLE_EVENTS, null, values);
        return rowId != -1;
    }
    public void startUserProfileActivity(Context context, int userId) {
        Intent userProfileIntent = new Intent(context, UserProfileActivity.class);
        userProfileIntent.putExtra("userId", userId); // Pass the user ID to the UserProfileActivity
        context.startActivity(userProfileIntent);
    }
    public int getUserId(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_USERNAME + "=?", new String[]{username});

        int userId = -1;
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int idIndex = cursor.getColumnIndex(COLUMN_ID);

            // Check if the column index is non-negative
            if (idIndex != -1) {
                userId = cursor.getInt(idIndex); // Get the user ID
            }
        }
        cursor.close();
        return userId;
    }
    public boolean deleteEvent(int eventId) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(eventId)});
        return rowsDeleted > 0;
    }

}