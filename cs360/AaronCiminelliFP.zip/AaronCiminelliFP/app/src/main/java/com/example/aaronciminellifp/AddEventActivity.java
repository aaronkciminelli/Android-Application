package com.example.aaronciminellifp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        EditText eventDetailsEditText = findViewById(R.id.eventDetailsEditText);
        EditText eventDateEditText = findViewById(R.id.eventDateEditText);
        EditText eventTimeEditText = findViewById(R.id.eventTimeEditText);
        EditText eventLocationEditText = findViewById(R.id.eventLocationEditText);
        Button saveEventButton = findViewById(R.id.saveEventButton);

        int userId = getIntent().getIntExtra("userId", -1);

        saveEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String details = eventDetailsEditText.getText().toString();
                String date = eventDateEditText.getText().toString();
                String time = eventTimeEditText.getText().toString();
                String location = eventLocationEditText.getText().toString();

                EventPlannerDatabase eventPlannerDatabase = EventPlannerDatabase.getInstance(AddEventActivity.this);
                if (eventPlannerDatabase.addEvent(userId, details, date, time, location)) {
                    Toast.makeText(AddEventActivity.this, "Event saved successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AddEventActivity.this, "Failed to save event", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
