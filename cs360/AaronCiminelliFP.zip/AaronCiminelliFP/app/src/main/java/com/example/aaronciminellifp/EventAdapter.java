package com.example.aaronciminellifp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private ArrayList<Event> events;
    private OnEventClickListener mListener;

    public EventAdapter(ArrayList<Event> events, OnEventClickListener listener) {
        this.events = events;
        this.mListener = listener;
    }

    public interface OnEventClickListener {
        void onEventClick(int position);
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_list_item, parent, false);
        return new EventViewHolder(itemView, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event currentEvent = events.get(position);
        holder.eventDetailsTextView.setText(currentEvent.getDetails());
        holder.eventDateTextView.setText(currentEvent.getDate());
        holder.eventTimeTextView.setText(currentEvent.getTime());
        holder.eventLocationTextView.setText(currentEvent.getLocation());
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        public TextView eventDetailsTextView;
        public TextView eventDateTextView;
        public TextView eventTimeTextView;
        public TextView eventLocationTextView;

        public EventViewHolder(@NonNull View itemView, OnEventClickListener listener) {
            super(itemView);
            eventDetailsTextView = itemView.findViewById(R.id.event_details_text_view);
            eventDateTextView = itemView.findViewById(R.id.event_date_text_view);
            eventTimeTextView = itemView.findViewById(R.id.event_time_text_view);
            eventLocationTextView = itemView.findViewById(R.id.event_location_text_view);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onEventClick(position);
                        }
                    }
                }
            });
        }
    }
}
