package com.example.aaronciminellifp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DeleteEventActivity extends AppCompatActivity {

    private Button deleteEventButton;
    private EventPlannerDatabase eventPlannerDatabase;
    private int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_event);

        deleteEventButton = findViewById(R.id.deleteEventButton);
        eventPlannerDatabase = EventPlannerDatabase.getInstance(this);
        eventId = getIntent().getIntExtra("eventId", -1);

        deleteEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventPlannerDatabase.deleteEvent(eventId);
                Toast.makeText(DeleteEventActivity.this, "Event deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
