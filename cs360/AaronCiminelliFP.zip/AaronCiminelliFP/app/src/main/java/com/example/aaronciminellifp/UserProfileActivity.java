package com.example.aaronciminellifp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class UserProfileActivity extends AppCompatActivity implements EventAdapter.OnEventClickListener {

    private int userId;
    private EventPlannerDatabase database;
    private ArrayList<Event> events;
    private RecyclerView recyclerView;
    private int selectedEventPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Get the user ID from the intent
        userId = getIntent().getIntExtra("userId", -1);

        // Initialize views
        Button logoutButton = findViewById(R.id.logoutButton);
        FloatingActionButton addEventButton = findViewById(R.id.addEventButton);
        FloatingActionButton editEventButton = findViewById(R.id.editEventButton);
        FloatingActionButton deleteEventButton = findViewById(R.id.deleteEventButton);
        FloatingActionButton shareEventButton = findViewById(R.id.shareEventButton);

        CalendarView calendarView = findViewById(R.id.calendarView);

        // Populate the events list and customize the calendar view to show events on a particular day
        database = EventPlannerDatabase.getInstance(this);
        events = database.eventList();

        EventAdapter adapter = new EventAdapter(events, this);

        recyclerView = findViewById(R.id.events_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show a toast message
                Toast.makeText(UserProfileActivity.this, "Logout successful", Toast.LENGTH_SHORT).show();

                // Launch the MainActivity
                Intent intent = new Intent(UserProfileActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // finish the current activity
            }
        });
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding event action here
                Intent intent = new Intent(UserProfileActivity.this, AddEventActivity.class);
                intent.putExtra("userId", userId);
                startActivity(intent);
            }
        });

        editEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle edit event action here
                if (selectedEventPosition != -1) {
                    Event eventToEdit = events.get(selectedEventPosition);
                    Intent intent = new Intent(UserProfileActivity.this, EditEventActivity.class);
                    intent.putExtra("userId", userId);
                    intent.putExtra("eventId", eventToEdit.getId());
                    startActivity(intent);
                } else {
                    Toast.makeText(UserProfileActivity.this, "Please select an event", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleteEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle delete event action here
                if (selectedEventPosition != -1) {
                    Event eventToDelete = events.get(selectedEventPosition);
                    database.deleteEvent(eventToDelete.getId());
                    events.remove(selectedEventPosition);
                    recyclerView.getAdapter().notifyItemRemoved(selectedEventPosition);
                    selectedEventPosition = -1;
                    Toast.makeText(UserProfileActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UserProfileActivity.this, "Please select an event", Toast.LENGTH_SHORT).show();
                }
            }
        });

        shareEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle share event action here
                if (selectedEventPosition != -1) {
                    Event eventToShare = events.get(selectedEventPosition);
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, eventToShare.toString());
                    sendIntent.setType("text/plain");

                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                } else {
                    Toast.makeText(UserProfileActivity.this, "Please select an event", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onEventClick(int position) {
        selectedEventPosition = position;
        Toast.makeText(this, "Selected event at position: " + position, Toast.LENGTH_SHORT).show();
    }

}
