package com.example.aaronciminellifp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity implements EventAdapter.OnEventClickListener {

    private EventPlannerDatabase database;
    private ArrayList<Event> events;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        database = EventPlannerDatabase.getInstance(this);
        events = database.eventList();

        EventAdapter adapter = new EventAdapter(events, this);

        recyclerView = findViewById(R.id.events_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onEventClick(int position) {
        Toast.makeText(this, "Selected event at position: " + position, Toast.LENGTH_SHORT).show();
    }
}
