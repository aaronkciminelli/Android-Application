package com.example.aaronciminellifp;

public class Event {
    private int id;
    private String details;
    private String date;
    private String time;
    private String location;
    private int userId;

    public Event(int id, String details, String date, String time, String location, int userId) {
        this.id = id;
        this.details = details;
        this.date = date;
        this.time = time;
        this.location = location;
        this.userId = userId;
    }

    public int getId() {
        return id;
    }

    public String getDetails() {
        return details;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public int getUserId() {
        return userId;
    }
}
